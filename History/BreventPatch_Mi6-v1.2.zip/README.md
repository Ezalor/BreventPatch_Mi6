# 黑域 services.jar 补丁
替换打过黑域补丁的 services.jar。

当前版本：Mi 6 v7.6.21
## 更新日志
v1.1

    - 同步 v7.6.20 （以后仅更新 MIUI 版本不再写更新日志）
v1

    - 第一版
